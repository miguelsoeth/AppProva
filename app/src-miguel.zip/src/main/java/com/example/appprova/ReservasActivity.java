package com.example.appprova;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ReservasActivity extends AppCompatActivity {

    private Button btnConfiguracoes;

    private LinearLayout mesaUm;
    private Button btnMesaUm;

    private LinearLayout mesaDois;
    private Button btnMesaDois;

    private LinearLayout mesaTres;
    private Button btnMesaTres;

    private LinearLayout mesaQuatro;
    private Button btnMesaQuatro;

    private int corPadrao;
    private int corReservado;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservas);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(ReservasActivity.this);
        int corReservaShared = preferences.getInt(Shared.KEY_COR_RESERVA, getColor(R.color.red));
        corReservado = corReservaShared;
        corPadrao = getColor(R.color.green);

        btnConfiguracoes = findViewById(R.id.btnConfiguracoes);

        mesaUm = findViewById(R.id.mesaUm);
        btnMesaUm = findViewById(R.id.btnMesaUm);
        setMesaButtonListener(btnMesaUm, mesaUm);

        mesaDois = findViewById(R.id.mesaDois);
        btnMesaDois = findViewById(R.id.btnMesaDois);
        setMesaButtonListener(btnMesaDois, mesaDois);

        mesaTres = findViewById(R.id.mesaTres);
        btnMesaTres = findViewById(R.id.btnMesaTres);
        setMesaButtonListener(btnMesaTres, mesaTres);

        mesaQuatro = findViewById(R.id.mesaQuatro);
        btnMesaQuatro = findViewById(R.id.btnMesaQuatro);
        setMesaButtonListener(btnMesaQuatro, mesaQuatro);

        btnConfiguracoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(ReservasActivity.this, ConfiguracoesActivity.class);
                startActivityForResult(it, 1);
            }
        });

        iniciarReservados();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                int res = data.getIntExtra(Shared.KEY_COR_RESERVA, corPadrao);

                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(ReservasActivity.this);
                SharedPreferences.Editor edit = preferences.edit();
                edit.putInt(Shared.KEY_COR_RESERVA, res);
                edit.apply();

                corReservado = res;
                atualizarCorMesas(corReservado);
            }
        }
    }

    private void setMesaButtonListener(Button button, final LinearLayout mesa) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int corAtual = ((ColorDrawable) mesa.getBackground()).getColor();

                if (corAtual == corPadrao) {
                    mesa.setBackgroundColor(corReservado);
                } else {
                    mesa.setBackgroundColor(corPadrao);
                }

                AtualizarSharedPreferencesMesa(mesa);
            }
        });
    }

    private void iniciarReservados() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(ReservasActivity.this);
        InicializarCorMesa(mesaUm, preferences.getInt(String.valueOf(mesaUm.getId()), corPadrao));
        InicializarCorMesa(mesaDois, preferences.getInt(String.valueOf(mesaDois.getId()), corPadrao));
        InicializarCorMesa(mesaTres, preferences.getInt(String.valueOf(mesaTres.getId()), corPadrao));
        InicializarCorMesa(mesaQuatro, preferences.getInt(String.valueOf(mesaQuatro.getId()), corPadrao));
    }

    private void atualizarCorMesas(int Cor) {
        atualizarMesaReservada(mesaUm, Cor);
        atualizarMesaReservada(mesaDois, Cor);
        atualizarMesaReservada(mesaTres, Cor);
        atualizarMesaReservada(mesaQuatro, Cor);
    }

    private void InicializarCorMesa(final LinearLayout mesa, int Cor) {
        int corAtual = ((ColorDrawable) mesa.getBackground()).getColor();
        if (corAtual != Cor) {
            //Toast.makeText(ReservasActivity.this, "ENTROU", Toast.LENGTH_SHORT).show();
            mesa.setBackgroundColor(Cor);
        }
    }

    private void atualizarMesaReservada(final LinearLayout mesa, int Cor) {
        int corAtual = ((ColorDrawable) mesa.getBackground()).getColor();
        if (corAtual != corPadrao) {
            mesa.setBackgroundColor(Cor);
        }
        AtualizarSharedPreferencesMesa(mesa);
    }

    private void AtualizarSharedPreferencesMesa(final LinearLayout mesa) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(ReservasActivity.this);
        SharedPreferences.Editor edit = preferences.edit();
        int corAtual = ((ColorDrawable) mesa.getBackground()).getColor();
        edit.putInt(String.valueOf(mesa.getId()), corAtual);
        edit.apply();
    }
}
