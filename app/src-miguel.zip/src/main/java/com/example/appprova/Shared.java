package com.example.appprova;

public class Shared {

    public static final String KEY_COR_RESERVA = "KEY_COR_RESERVA";
}
